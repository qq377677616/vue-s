module.exports = {  
  //多语言页面  
  my: {
    title: '多语言',
    top_button: '切换语言',
    nickname: '这是昵称',
    list: ['我的病历', '我的处方', '我的体检报告', '我的订单', '我的医生', '我的药师', '血糖助手']
  }
}