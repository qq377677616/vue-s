module.exports = { 
  //多语言页面  
  my: {
    title: 'Multilingual',
    top_button: 'Switch Language',
    nickname: 'This is a nickname',
    list: ['My medical record', 'My prescription', 'My medical report', 'My order', 'My doctor', 'My pharmacist', 'Blood sugar assistant']
  }
}