module.exports = {   
  //多语言页面  
  my: {
    title: '多語言',
    top_button: '切換語言',
    nickname: '這是昵稱',
    list: ['我的病歷', '我的處方', '我的體檢報告', '我的訂單', '我的醫生', '我的藥師', '血糖助手']
  }
}